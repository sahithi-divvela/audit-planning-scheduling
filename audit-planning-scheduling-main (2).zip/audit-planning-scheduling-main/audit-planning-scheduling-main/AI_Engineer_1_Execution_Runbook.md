# AI Engineer 1: Complete Execution Runbook & Demo Guide

**Project:** Tool-21 Audit Planning and Scheduling
**Role:** AI Developer 1
**Purpose:** This document is compiled so you can easily run, test, and demo your specific portion of the project on *any* machine (like your friend's laptop).

---

## 📁 1. Your Marked Files (AI Developer 1 Scope)

If anyone asks what exactly you built, point them to these files inside the `ai-service/` folder:

*   **Entry Point & Config:**
    *   `app.py` (Flask setup, blueprints registration, rate limiting)
    *   `requirements.txt` (Dependencies)
    *   `.env` (Environment variables and API keys)
    *   `README.md` (AI Service documentation)
*   **API Routes (Endpoints):**
    *   `routes/describe.py`
    *   `routes/recommend.py`
    *   `routes/generate_report.py` (Includes SSE streaming)
    *   `routes/analyse_document.py`
    *   `routes/batch_process.py`
    *   `routes/query.py` (RAG pipeline endpoint)
*   **Services & Logic:**
    *   `services/rag_service.py` (ChromaDB + sentence-transformers)
    *   `services/groq_client.py` (Llama-3 API integration)
    *   `services/ai_workflows.py` (Business logic tying everything together)
*   **Testing:**
    *   `tests/test_endpoints.py` (Pytest unit tests)

---

## ⚙️ 2. Quick Setup Instructions (For your friend's laptop)

When you move this project to a new laptop, follow these exact steps to get the AI service running.

**1. Open PowerShell and navigate to the `ai-service` folder:**
```powershell
cd path\to\audit-planning-scheduling-main\ai-service
```

**2. Create a virtual environment and activate it:**
```powershell
python -m venv .venv
.\.venv\Scripts\activate
```

**3. Install dependencies:**
```powershell
pip install -r requirements.txt
```

**4. Verify your API Key:**
Ensure the `.env` file exists in the `ai-service` folder and contains your key:
```text
GROQ_API_KEY=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
```

---

## 🚀 3. How to Run the Server

Once setup is complete, start the server with:
```powershell
python app.py
```
*You should see output indicating the server is running on `http://127.0.0.1:5000`.*

---

## ⚡ 4. How to Check/Test Fast (Pre-Demo Validation)

Open a **new** PowerShell window (keep the server running in the first one) and run these commands to instantly verify your endpoints are working.

**Check Health:**
```powershell
Invoke-WebRequest -Uri http://127.0.0.1:5000/health -Method GET | Select-Object -ExpandProperty Content
```
*Expected: `"status": "ok"`*

**Test Llama-3 AI Recommendation:**
```powershell
$body = '{"text":"An audit is delayed because evidence is incomplete."}'
Invoke-WebRequest -Uri http://127.0.0.1:5000/recommend -Method POST -Body $body -ContentType "application/json" | Select-Object -ExpandProperty Content
```
*Expected: A real JSON response with 3 actionable recommendations and `"is_fallback": false`.*

---

## 🎤 5. Your 2-Minute Demo Script

During the team demo, when it is your turn to present the "AI Features":

**1. Introduction:**
> "Hello everyone, my name is [Your Name] and I'll be walking you through the AI capabilities of our application. We integrated a robust AI layer to help automate and streamline the audit planning process."

**2. Demonstrate AI Recommend (`/recommend`):**
> "Here, we have a potentially delayed audit. Let's see what our AI suggests. By clicking 'Recommend', our Flask microservice securely calls the Groq Llama-3 model."
*(Read out one of the recommendations on the screen)*
> "As you can see, the AI immediately generated three structured, actionable recommendations with assigned priorities, helping managers make quick decisions."

**3. Demonstrate Generate Report (`/generate-report`):**
> "Preparing audit reports manually takes hours. Watch what happens when I generate an automated report."
*(Show the SSE streaming text)*
> "Notice the text streaming in real-time. We implemented Server-Sent Events (SSE) so users don't have to wait for the entire generation process to finish before they can start reading."

**4. Demonstrate RAG Query (`/query`):**
> "Finally, let me show you our RAG pipeline—Retrieval-Augmented Generation. We seeded our local ChromaDB vector database with domain-specific knowledge documents using `sentence-transformers`. When I ask a question like 'What should be checked first in audit planning?', the AI doesn't just guess."
*(Show the answer and sources)*
> "It searches our local database, retrieves the most relevant context, and generates an accurate answer while citing the exact sources it used."

**5. Hand-off:**
> "That covers the primary AI workflows. I'll now hand it over to my colleague to discuss our analytics and UI dashboard."

---

## 🆘 6. Troubleshooting (Just in case!)

*   **API Error / Empty Responses:** Check the terminal running `app.py`. If you see Groq authentication errors, verify your `.env` file has the correct `GROQ_API_KEY`.
*   **"HTTP 429 Too Many Requests":** You hit the endpoints too fast! Your security rate-limiter is doing its job (max 30 requests per minute). Just wait 60 seconds and try again.
*   **"Connection Refused" when testing:** Your Flask server is not running. Make sure you ran `python app.py` and it didn't crash.

---

## 🛑 7. GitHub Submission (What to push and what NOT to push)

When you are ready to upload or push your code for your role, you need to be very careful.

**✅ NEW / MODIFIED FILES TO PUSH:**
*   `ai-service/app.py`: This was heavily modified to fix a critical bug. It now properly wires up your actual AI endpoints and registers the `flask-talisman` security headers.
*   `AI_Engineer_1_Execution_Runbook.md`: This very file! It's a great piece of documentation to show your team.

**❌ CRITICAL: FILES YOU MUST NEVER PUSH:**
*   `ai-service/.env`: **NEVER push this file!** It contains your secret `GROQ_API_KEY`. The Project PDF explicitly warns that committing this is an automatic failure. It should be ignored by `.gitignore`.
*   `ai-service/.venv/`: Never push your virtual environment. It is too large and machine-specific.
*   `__pycache__/`: Python cache folders should be ignored.

*(Note: The files `read_pdf.py` and `pdf_content.txt` in your root folder were temporary scratch files I used to read your instructions. You can safely delete them before pushing).*
